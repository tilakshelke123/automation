package test;

import org.testng.annotations.Test;

public class ALab9_IgnoreMissingDependencies {
	// mm naam ko koi method he nhi hai to vo ignore krega is se  "ignoreMissingDependencies = true"
	// defaultly ye false hota hai 
	@Test(dependsOnMethods = "mm",ignoreMissingDependencies = true) 
	public void m2() throws InterruptedException {
		System.out.println("Method m2");
	}
	
	@Test
	public void m1() {
		System.out.println("Method m1");
	}
	
	@Test
	public void m3() {
		System.out.println("Method m3");
	}
	
}
