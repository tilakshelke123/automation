package test;

import org.testng.annotations.Test;

@Test
public class BLab13_ClassLevelTest {

	public void m2() throws InterruptedException {
		System.out.println("Method m2");
	}
	
	public void m1() {
		System.out.println("Method m1");
	}
	
	public void m3() {
		System.out.println("Method m3");
	}

	public void m4() {
		System.out.println("Method m4");
	}
	
}
