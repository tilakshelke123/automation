package listeners;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class Listeners implements ITestListener {

	@Override
	public void onFinish(ITestContext context) {
		System.out.println("OnFinish");
	}
	
	@Override
	public void onStart(ITestContext context) {
		System.out.println("OnStart");
	}
	
	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("OnSuccess:"+result.getName());
	}
	
	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println("OnFailure");
	}
	
	@Override
	public void onTestStart(ITestResult result) {
		System.out.println("OnTestStart:"+result.getName());
	}
	
}
