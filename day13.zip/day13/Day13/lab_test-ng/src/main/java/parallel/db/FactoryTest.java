package parallel.db;

import org.testng.annotations.Factory;

import parallel.ui.UITest1;


public class FactoryTest {

	@Factory
	public Object[] testCases() {
		return new Object[] {
	            new UITest1(),
	            new DBTest1(),
	            new DBTest2()
	        };
	}
}
