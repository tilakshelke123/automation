package main;

import testcase.LoginTestCase;

public class Main {

	public static void main(String[] args) {
		new LoginTestCase().login();
	}

}
