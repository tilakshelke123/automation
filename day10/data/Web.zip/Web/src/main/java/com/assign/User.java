package com.assign;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class User {

	private String username;
	private String password;

	public static void main(String[] args) {

		String path = "testdata.xlsx";
		try (FileInputStream fos = new FileInputStream(path); Workbook work = WorkbookFactory.create(fos)) {
			
			//sheet 
			Sheet sheet = work.getSheet("Sheet1");
			int lastRow = sheet.getLastRowNum();
			
			List <User> user = readLogin(path);
			
			System.out.println("user size "+user.size());
			
			for(User use:user) {
				System.out.println("username"+use.username+ "password"+ use.password);
				
				
			}
			
			
		} catch (Exception e) {
       System.out.println("geeting data to be failed !!!");
		}

	}

	private static List<User> readLogin(String path) {
		
		return ;
	}

}
